import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { TableComponent } from './table/table.component';
import {TableModule} from 'primeng/table';
import { SelectTableDirective } from './directives/select-table.directive';
import { SelectTable1Directive } from './directives/select-table1.directive';


@NgModule({
  declarations: [
    AppComponent,
    TableComponent,
    SelectTableDirective,
    SelectTable1Directive
  ],
  imports: [
    BrowserModule,
    TableModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
