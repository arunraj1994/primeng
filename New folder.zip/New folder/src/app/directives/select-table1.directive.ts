import { Directive } from '@angular/core';
import { ElementRef } from '@angular/core';
import { Renderer, ContentChild, AfterViewInit } from '@angular/core';
import { HostListener } from '@angular/core'


@Directive({
  selector: '[appSelectTable1]'
})
export class SelectTable1Directive {
  @ContentChild('tableRef1') child: ElementRef;

  constructor(private el: ElementRef,
    private renderer: Renderer) {
    console.log(el.nativeElement);
    renderer.setElementStyle(el.nativeElement, 'backgroundColor', 'green');

  }
  // @HostListener('body:keyup', ['$event'])
  // onKeyUp(kbdEvent: KeyboardEvent) {
  //   console.log(kbdEvent)
  // }
  ngAfterViewInit() {

    console.log(document.activeElement.tagName);
    this.renderer.listen(this.el.nativeElement, 'click', (event) => {
      console.log("hgvjhfgh", event);
    });
  }

}
