import { SelectTable1Directive } from './select-table1.directive';

describe('SelectTable1Directive', () => {
  it('should create an instance', () => {
    const directive = new SelectTable1Directive();
    expect(directive).toBeTruthy();
  });
});
