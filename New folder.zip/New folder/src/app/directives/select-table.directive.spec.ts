import { SelectTableDirective } from './select-table.directive';

describe('SelectTableDirective', () => {
  it('should create an instance', () => {
    const directive = new SelectTableDirective();
    expect(directive).toBeTruthy();
  });
});
